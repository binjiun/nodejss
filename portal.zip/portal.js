const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"

get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------


function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}


get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}


get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}

// DKQ--------------------------------------------------------------------------


get_course_data = function () {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.dkq_course;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_course_certified_data = function () {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.dkq_course_certified;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_step_data = function (sn) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.dqk_step where course_id =" + sn + ";";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_step_certified_data = function (sn) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.dkq_step_certified where course_id =" + sn + ";"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

update_field_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        const sql = "UPDATE `binjiun_project`.`dkq_course_certified` SET `result` = ?, `updator` = ?, `updatetime` = ? WHERE (`course_key` = ?) and `name` = ?;";
        connection.query(sql, data, function (err, rows) {
            if (err) {
                console.log('[UPDATE ERROR] - ', err.message);
                return;
            }

            console.log('--------------------------INSERT----------------------------');
            console.log('UPDATE ID:', rows);
            console.log('-----------------------------------------------------------------\n\n');
        }
        )
    }
    )
}

update_step_field_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "UPDATE `binjiun_project`.`dkq_step_certified` SET `result` = ?, `updator` = ?, `updatetime` = ? WHERE (`course_id` = ?) and  (`step_key` = ?)  and (`name` = ?);";
        connection.query(
            sql, data,
            function (err, rows) {
                if (err) {
                    console.log('[UPDATE ERROR] - ', err.message);
                    return;
                }

                console.log('--------------------------INSERT----------------------------');
                console.log('UPDATE ID:', rows);
                console.log('-----------------------------------------------------------------\n\n');
            }
        )
    }
    )
}


// dl edit api--------------------------------------------------------------------------

get_dl_data = function (dep) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l7b_dl_edit where dept ='" + dep + "';"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

update_dl_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        const sql = "UPDATE `binjiun_project`.`l7b_dl_edit` SET `ISACTIVE` = ?, `UPDATETOR` = ?, `UPDATETIME` = ? WHERE (`sn` = ?) and `NAME` = ?;";
        connection.query(sql, data, function (err, rows) {
            if (err) {
                console.log('[UPDATE ERROR] - ', err.message);
                return;
            }

            console.log('--------------------------INSERT----------------------------');
            console.log('UPDATE ID:', rows);
            console.log('-----------------------------------------------------------------\n\n');
        }
        )
    }
    )
}

//  IOT SQL 

get_estone_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT dep,type, count(type) as count FROM binjiun_project.l7b_iot_estone where reply = 'N' and dep in ('ML7BB1', 'ML7BB2', 'ML7BE1', 'ML7BE2', 'ML7BT1', 'ML7BT2', 'ML7BP1', 'ML7BP2', 'ML7BI3','ML7BL1', 'ML7BC2', 'ML7BN1', 'ML7BN2', 'ML7BH1', 'ML7BH2') group by dep,type ;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_estone_data_sum = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT dep , count(type) as sum FROM binjiun_project.l7b_iot_estone where reply = 'N' and dep in ('ML7BB1', 'ML7BB2', 'ML7BE1', 'ML7BE2', 'ML7BT1', 'ML7BT2', 'ML7BP1', 'ML7BP2', 'ML7BI3','ML7BL1', 'ML7BC2', 'ML7BN1', 'ML7BN2', 'ML7BH1', 'ML7BH2') group by dep ;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}


get_dep_estone_data = function (dep) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT  * FROM binjiun_project.l7b_iot_estone where reply = 'N' and dep ='" + dep + "'"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_dep_estone_data_all = function (dep) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = '';
        if (dep == 'L7B') {
            sql = "SELECT  * FROM binjiun_project.l7b_iot_estone"
        } else {
            sql = "SELECT  * FROM binjiun_project.l7b_iot_estone where dep ='" + dep + "'"
        }
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

update_estone_data = function (sn, replycontent, name) {
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = ("0" + date_ob.getHours()).slice(-2);
    let minutes = ("0" + date_ob.getMinutes()).slice(-2);
    let seconds = ("0" + date_ob.getSeconds()).slice(-2);
    let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;

    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "UPDATE `binjiun_project`.`l7b_iot_estone` SET `reply` = 'Y',  `closetime` = '" + now_date + "', `replycontent` = '" + replycontent + "', `closename` = '" + name + "' WHERE (`sn` = '" + sn + "');"
    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });

}



get_estone_api_data = function (number) {
    return new Promise(
        function (resolve, reject) {
            var post_data = JSON.stringify({
                "status": ["Finish"],
                "map_key": "L7B_IOT_2203024",
                "include_subtask": "N"
            });
            var post_options = {
                host: '10.5.13.187',
                port: 8080,
                path: '/EstoneApi/API/APITask/QxTaskInfoByMapKeyExt',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api_key': '9a32a1e0f48e05ec86d5f78ef8932475',
                    'Content-Length': Buffer.byteLength(post_data)
                }
            };

            var post_req = http.request(post_options, function (res) {
                res.setEncoding('utf8');
                res.on('data', function (data) {
                    try {
                        resolve(JSON.parse(data)['infos'].map(function (element) {
                            return { task_id: element.task_id, status: element.status }
                        }));
                    } catch {
                        return {}
                    }
                });
            });

            post_req.write(post_data);
            post_req.end();
        }
    )
}


//DL_score_sql

dl_month_data = function (name) {
    return new Promise(
        function (resolve, reject) {
            let date_ob = new Date();
            date_ob.setDate(date_ob.getDate() - 31);
            let date = ("0" + date_ob.getDate()).slice(-2);
            let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
            let year = date_ob.getFullYear();
            let hours = ("0" + date_ob.getHours()).slice(-2);
            let minutes = ("0" + date_ob.getMinutes()).slice(-2);
            let seconds = ("0" + date_ob.getSeconds()).slice(-2);
            let last_date = year + "-" + month + "-01";
            console.log(last_date);
            const connection = mysql.createConnection({
                host: 'tw100043811',
                user: 'l7b01_ap',
                password: 'l7b01$ap',
                port: '3306',
                database: 'binjiun_project'
            });
            connection.connect();
            var sql = "SELECT * FROM binjiun_project.l7b_aiproject_dl_score_data_ini  where Name='" + name + "'  and ISCheck ='Y'  and Date >= '" + last_date + "' ;"
            connection.query(sql, function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }

            });
        })
}


dl_year_data = function (name) {
    return new Promise(
        function (resolve, reject) {
            let date_ob = new Date();
            date_ob.setDate(date_ob.getDate() - 180);
            let date = ("0" + date_ob.getDate()).slice(-2);
            let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
            let year = date_ob.getFullYear();
            let hours = ("0" + date_ob.getHours()).slice(-2);
            let minutes = ("0" + date_ob.getMinutes()).slice(-2);
            let seconds = ("0" + date_ob.getSeconds()).slice(-2);
            let last_date = year + "-" + month + "-01";
            console.log(last_date);
            const connection = mysql.createConnection({
                host: 'tw100043811',
                user: 'l7b01_ap',
                password: 'l7b01$ap',
                port: '3306',
                database: 'binjiun_project'
            });
            connection.connect();
            var sql = "SELECT * FROM binjiun_project.l7b_aiproject_dl_score_data_ini  where Name='" + name + "'   and ISCheck ='Y'   and  Date >= '" + last_date + "' ;"
            connection.query(sql, function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }

            });
        })
}

dl_edit_data = function (dep) {
    return new Promise(
        function (resolve, reject) {

            const connection = mysql.createConnection({
                host: 'tw100043811',
                user: 'l7b01_ap',
                password: 'l7b01$ap',
                port: '3306',
                database: 'binjiun_project'
            });
            connection.connect();
            var sql = "SELECT * FROM binjiun_project.l7b_aiproject_dl_score_data_ini  where Dept='" + dep + "'  and ISCheck ='N'  ;"
            connection.query(sql, function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }

            });
        })
}


update_dl_dep_data = function (dep) {


    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "UPDATE `binjiun_project`.`l7b_aiproject_dl_score_data_ini` SET `ISCheck` = 'Y' WHERE  Dept='" + dep + "' and (`Date` >= '2000-01-01') and (`ID` >= '0') and total > 0;"

    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });

}

update_dl_score_data = function (field, value, Date_data, ID) {


    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "UPDATE `binjiun_project`.`l7b_aiproject_dl_score_data_ini` SET `" + field + "` = '" + value + "' WHERE (`Date` = '" + Date_data + "') and (`ID` = '" + ID + "');"

    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });

}





//------------------------------------------------------------------------------
module.exports = function () {

    //DL_score_sql
    router.post('/portal/dl_year_data', urlencodedParser, function (req, res) {
        var name = req.body.name;
        dl_year_data(name)
            .then(function (results) {
                res.json(results);
            });
    });
    router.post('/portal/dl_month_data', urlencodedParser, function (req, res) {
        var name = req.body.name;
        dl_month_data(name)
            .then(function (results) {
                res.json(results);
            });
    });
    router.post('/portal/dl_edit_data', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        dl_edit_data(dep)
            .then(function (results) {
                res.json(results);
            });
    });
    router.post('/portal/update_dl_score_data', urlencodedParser, function (req, res) {
        var field = req.body.field;
        var value = req.body.value;
        var Date_data = req.body.Date_data;
        var ID = req.body.ID_data;
        update_dl_score_data(field, value, Date_data, ID)
        res.json({ 'msg': 'OK' });
    });
    router.post('/portal/update_dl_dep_data', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        update_dl_dep_data(dep)
        res.json({ 'msg': 'OK' });
    });




    // IOT JSON API
    // router.post('/portal/update_estone_data_all', urlencodedParser, function (req, res) {
    //     var dep = req.body.dep_estone_id;
    //     var Solution = req.body.Solution;
    //     var action_time = req.body.action_time;
    //     var replycontent = req.body.replycontent;
    //     update_estone_data_all(dep, String(Solution) + '-' + String(action_time) + '-' + String(replycontent))
    //     res.json({ 'msg': 'OK' });;
    // });

    router.post('/portal/update_estone_data', urlencodedParser, function (req, res) {
        var sn = req.body.sn;
        var replycontent = req.body.replycontent;
        get_ip_hostname(req.headers['x-forwarded-for']).then(function (name) {
            get_person_data(name)
                .then(function (results) {
                    if (results.length == 0) {
                        res.json({ 'msg': 'NG' });
                    } else {
                        update_estone_data(sn, replycontent, results[0].USER_NAME)
                        res.json({ 'msg': 'OK' });
                    }

                })
        })
    });

    router.get('/portal/get_estone', urlencodedParser, function (req, res) {
        Promise.all([get_estone_data(), get_estone_data_sum()])
            .then(function (results) {
                res.json(results);
            });
    });
    router.post('/portal/get_dep_estone_data', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        get_dep_estone_data(dep)
            .then(function (results) {
                res.json(results);
            });
    });

    router.post('/portal/get_dep_estone_data_all', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        get_dep_estone_data_all(dep)
            .then(function (results) {
                res.json(results);
            });
    });


    //DL edit json api-------------------------------------
    router.post('/portal/getdl', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        get_dl_data(dep)
            .then(function (results) {
                res.json(results);
            });
    });
    router.post('/portal/update_dl_data', urlencodedParser, function (request, res) {
        var id = request.body.id;
        var result = request.body.result;
        var body_name = request.body.name;
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                update_dl_data([result, name, now_date, id, body_name])
            })
        })
        res.json({ 'msg': 'OK' });;
    });

    //DKQ json api-------------------------------------
    router.post('/portal/remove_row_data', urlencodedParser, function (request, res) {
        var sn = request.body.sn;
        var sql = "DELETE FROM `binjiun_project`.`dkq_course` WHERE (`sn` = '?');"
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            insert_43811(sql, [sn])
            res.json({ 'msg': 'OK' });;
        })
    });

    router.post('/portal/insert_row_data', urlencodedParser, function (request, res) {
        var dep = request.body.dep;
        var sql = "INSERT INTO `binjiun_project`.`dkq_course` (`dept`,`updator`, `updatetime`) VALUES (?,?,?);"
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                insert_43811(sql, [dep, name, now_date])
            })
            res.json({ 'msg': 'OK' });;
        })
    });


    router.post('/portal/update_field_data', urlencodedParser, function (request, res) {
        var id = request.body.id;
        var result = request.body.result;
        var body_name = request.body.name;
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                update_field_data([result, name, now_date, id, body_name])
            })
        })
        res.json({ 'msg': 'OK' });;
    });
    router.post('/portal/update_step_field_data', urlencodedParser, function (request, res) {
        var id = request.body.id;
        var id2 = request.body.id2;
        var result = request.body.result;
        var body_name = request.body.name;
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                update_step_field_data([result, name, now_date, id, id2, body_name])
            })
        })
        res.json({ 'msg': 'OK' });;
    });
    router.post('/portal/getcourse', urlencodedParser, function (req, res) {
        var dep = req.body.dep;
        Promise.all([get_course_data(), get_course_certified_data()])
            .then(function (results) {
                var usersInformation = [];
                for (var i in results[0]) {
                    if (dep == results[0][i].dept) {
                        var Y = 0;
                        var N = 0;
                        for (var j in results[1]) {
                            if (results[0][i].sn == results[1][j].course_key) {
                                results[0][i][results[1][j].name] = results[1][j].name + '_' + results[1][j].result;
                                if (results[1][j].result == 'Y') {
                                    Y = Y + 1;
                                } else {
                                    N = N + 1;
                                }
                                // console.log(  results[0][i][  results[1][j].name ]    );   
                                // console.log(results[1][j].name,results[1][j].result)
                            }
                        }
                        results[0][i]['Y'] = Y;
                        results[0][i]['N'] = N;
                        if ((Y + N) == 0) {
                            results[0][i]['P'] = 0
                        } else {
                            results[0][i]['P'] = String(Math.round(((Y) / (Y + N)) * 100)) + '%'
                        }
                        usersInformation.push(results[0][i])
                    }
                }
                res.json(usersInformation);

            });
    });

    router.get('/portal/gettotalplot', urlencodedParser, function (req, res) {
        Promise.all([get_course_data(), get_course_certified_data()])
            .then(function (results) {

                var dep = ['E1', 'E2', 'B1', 'B2', 'C1', 'C2', 'H2', 'I1', 'I2', 'I3', 'N1', 'N2', 'P1', 'P2', 'T1', 'T2', 'V1', 'V2'];
                var dep_count = [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                var dep_pass = [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                var dep_p = [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                for (var i in results[0]) {
                    for (var j in results[1]) {
                        if (results[0][i].sn == results[1][j].course_key) {
                            dep_count[ dep.findIndex(element => results[0][i].dept == element ) ] += 1;
                            if (results[1][j].result == 'Y') {
                                dep_pass[ dep.findIndex(element => results[0][i].dept == element )] += 1;
                            }
                        }
                    }
                }
                for(var i in dep_count){
                    dep_p[i] = parseInt((dep_pass[i]/dep_count[i])*100);
                }
                res.json({'dep':dep,'count':dep_count,'pass':dep_pass,'p':dep_p})
            })
    })

    router.post('/portal/getstep', urlencodedParser, function (req, res) {
        var sn = req.body.sn;
        Promise.all([get_step_data(sn), get_step_certified_data(sn)])
            .then(function (results) {
                var usersInformation = [];
                for (var i in results[0]) {
                    var Y = 0;
                    var N = 0;
                    for (var j in results[1]) {
                        if (results[0][i].sn == results[1][j].step_key) {
                            results[0][i][results[1][j].name] = results[1][j].name + '_' + results[1][j].result;
                            if (results[1][j].result == 'Y') {
                                Y = Y + 1;
                            } else {
                                N = N + 1;
                            }
                            // console.log(  results[0][i][  results[1][j].name ]    );   
                            // console.log(results[1][j].name,results[1][j].result)
                        }
                    }
                    results[0][i]['Y'] = Y;
                    results[0][i]['N'] = N;
                    if ((Y + N) == 0) {
                        results[0][i]['P'] = 0
                    } else {
                        results[0][i]['P'] = String(Math.round(((Y) / (Y + N)) * 100)) + '%'
                    }

                    usersInformation.push(results[0][i])

                }

                res.json(usersInformation);

            });
    });
    //router

    router.get('/portal', (request, response) => {
        if ((request.headers['user-agent']).includes('Trident')) {

            response.sendFile('swal.html', { root: __dirname })
        } else {

            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], '訪客', 'view Portal index', now_date])
                            })
                            response.render('./portal/ejs/index', { 'name': '訪客', 'id': '' })

                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], results[0].USER_NAME, 'view Portal index', now_date])
                            })
                            response.render('./portal/ejs/index', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })

                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })
            })


        }
    });

    router.get('/portal/IDL_Chart', (request, response) => {
        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);

            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
                get_date().then(function (now_date) {
                    insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW IOT', now_date])
                })
                response.sendFile('IDL_Chart.html', { root: __dirname })
            })


        }
    });
    router.get('/portal/IOT', (request, response) => {
        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);


            get_estone_api_data().then(function (results) {
                get_dep_estone_data_all('L7B').then(function (estone) {
                    console.log(results)
                    console.log(estone)
                    const db_status = Object.fromEntries(estone.map(x => [x.tasks, x.reply]))
                    const db_status_sn = Object.fromEntries(estone.map(x => [x.tasks, x.sn]))
                    for (var i in results) {
                        if (db_status[results[i].task_id] == 'N' & results[i].status == 'Finish') {
                            update_estone_data(db_status_sn[results[i].task_id], '此筆於estone網頁結案,回覆待撈取')
                        }
                    }
                })
            })

            //return_data
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], '訪客', 'VIEW IOT', now_date])
                            })
                            response.render('./portal/ejs/IOT', { 'name': '訪客', 'id': '' })

                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], results[0].USER_NAME, 'VIEW IOT', now_date])
                            })
                            response.render('./portal/ejs/IOT', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })

                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })
            })
        }
    });
    router.get('/portal/DKQ', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW DQK', now_date])
                            })
                            // response.render('./portal/ejs/dkq', { 'name': '訪客', 'id': '' })
                            response.render('./portal/ejs/error_person.ejs')
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW DQK', now_date])
                            })
                            response.render('./portal/ejs/dkq', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });
    router.get('/portal/DL', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], '訪客', 'VIEW DL', now_date])
                            })

                            // response.render('./portal/ejs/dl', { 'name': '訪客', 'id': '' })
                            response.render('./portal/ejs/error_person.ejs')
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], results[0].USER_NAME, 'VIEW DL', now_date])
                            })
                            response.render('./portal/ejs/dl', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });
    router.get('/portal/DL_edit', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], '訪客', 'VIEW DL_edit', now_date])
                            })

                            // response.render('./portal/ejs/dl_edit', { 'name': '訪客', 'id': '' })
                            response.render('./portal/ejs/error_person.ejs')
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], results[0].USER_NAME, 'VIEW DL_edit', now_date])
                            })
                            response.render('./portal/ejs/dl_edit', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });

    router.get('/portal/Material', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], '訪客', 'VIEW DL_edit', now_date])
                            })

                            // response.render('./portal/ejs/Material', { 'name': '訪客', 'id': '' })
                            response.render('./portal/ejs/error_person.ejs')
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], results[0].USER_NAME, 'VIEW DL_edit', now_date])
                            })
                            response.render('./portal/ejs/Materials', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });



    return router;
}