const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"
var formidable = require('formidable');
const multer  = require('multer')

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'router/portal/assets/images/gpkpi/')
    },
    filename: function (req, file, cb) {
        file.originalname = Buffer.from(file.originalname, "latin1").toString(
            "utf8"
        );

      cb(null, req.body.iday + '_' + req.body.creator +'_'+file.originalname)
    },
    limit: {
        // 限制上傳檔案的大小為 10MB
        fileSize: 10000000
    },
})
const upload = multer({storage: storage})

const storage_file = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'router/portal/assets/images/gpkpi/')
    },
    filename: function (req, file, cb) {
        file.originalname = Buffer.from(file.originalname, "latin1").toString(
            "utf8"
        );

      cb(null, req.body.upload_id.split('_')[1] + '_'+file.originalname)
    },
    limit: {
        // 限制上傳檔案的大小為 10MB
        fileSize: 10000000
    },
})
const upload_file = multer({storage: storage_file})

const storage_action = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'router/portal/assets/images/gpaction/')
    },
    filename: function (req, file, cb) {
        file.originalname = Buffer.from(file.originalname, "latin1").toString(
            "utf8"
        );

        cb(null, req.body.iday + '_' + req.body.creator +'_'+file.originalname)
    },
    limit: {
        // 限制上傳檔案的大小為 10MB
        fileSize: 10000000
    },
})
const upload_action = multer({storage: storage_action})

get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------

function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log(sql, data)
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}

get_43811_data = function (sql,data) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        connection.query(
            sql, data,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

function insert_43811_req(sql, data) {
    return new Promise(function (resolve, reject) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log(sql, data)
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
        resolve({'msg':'ok'});
    });
    connection.end();
    }
    )
}

get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.lcd2_c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}

//api

get_insert_gp_item_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l7b_gp_follow_item ORDER BY sn DESC LIMIT 1;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_gp_item_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l7b_gp_follow_item where `taskflag` = 'Y'  order by iday desc;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

update_dep_comment = function (dept,comment,name,now_date) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "Replace INTO `binjiun_project`.`l7b_gpkpi_power_comment` (`dept`, `comment`, `updator`, `updatetime`) VALUES ('"+dept+"', '"+comment+"', '"+name+"', '"+now_date+"');"
    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
}
get_l7b_gpkpi_power_comment_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l7b_gpkpi_power_comment;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}


module.exports = function () {
    // api action

    router.get('/portal/l7B_GP_KPI/get_gp_flowitem_count_data', urlencodedParser, function (req, res) {
        var sql = " SELECT substr(dept, length(dept)-1, 2) as DEPT," 
        sql +=  " Sum(1) as Total_Count," 
        sql +=  " Sum(Case When status = '結案' then 1 Else 0 End) as Finish," 
        sql +=  " Sum(Case When status <> '結案' then 1 Else 0 End) as Undone," 
        sql +=  " round((Sum(Case When status = '結案' then 1 Else 0 End) / Sum(1))*100,2) as Case_closure_rate " 
        sql +=  " FROM binjiun_project.l7b_gp_follow_item" 
        sql +=  " where taskflag = 'Y'" 
        sql +=  " Group by dept"
        get_43811_data(sql,[])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post('/portal/l7B_GP_KPI/post_editproject_apply_action', upload.single('file_png'), function (req, res) {
        var sn = req.body.edit_action;
        var iday = req.body.iday;
        var action_dept =  req.body.action_dept;
        var creator =  req.body.creator;
        var type =  req.body.type;
        var describe =  req.body.describe;
        var profit =  req.body.profit;
        var status =  req.body.status;
        var start_iday =  req.body.start_iday;
        if(req.file && req.file.originalname){
            var filename =  req.file.filename;
        }else{
            var filename = ''
        }
        var sql = "UPDATE `binjiun_project`.`l7b_gp_action_table` SET `status` = ?, `iday` = ?, `start_iday` = ?, `dept` = ?, `creator` = ?, `type` = ?, `describe` = ?, `profit` = ?, `file_png` = ?, `createtime` = ? WHERE (`sn` = '4');"
        get_date().then(function (now_date) {
            insert_43811(sql,[status,iday,start_iday,action_dept,creator,type,describe,profit,filename,now_date,sn])
            res.json([{ 'msg': 'OK' }]);
        })
    });  

    router.post('/portal/l7B_GP_KPI/post_add_action', upload_action.single('file_png'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var iday = req.body.iday;
        var action_dept =  req.body.action_dept;
        var creator =  req.body.creator;
        var type =  req.body.type;
        var describe =  req.body.describe;
        var profit =  req.body.profit;
        var status =  req.body.status;
        var start_iday =  req.body.start_iday;
        if(req.file && req.file.originalname){
            var filename =  req.file.filename;
        }else{
            var filename = ''
        }
        var sql = "INSERT INTO `binjiun_project`.`l7b_gp_action_table` (`iday`, `dept`, `creator`, `type`, `describe`, `profit`, `file_png`, `createtime`, `taskflag`, `status`, `start_iday`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
        get_date().then(function (now_date) {
            insert_43811(sql,[iday,action_dept,creator,type,describe,profit,filename,now_date,'Y',status,start_iday])
            res.json([{ 'msg': 'OK' }]);
        })
    }); 

    router.get('/portal/l7B_GP_KPI/get_gp_action_data', urlencodedParser, function (req, res) {
        var sql = "SELECT * FROM binjiun_project.l7b_gp_action_table where taskflag = 'Y' order by start_iday desc;"
        get_43811_data(sql,[])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post('/portal/l7B_GP_KPI/delete_action_item', urlencodedParser, function (req, res) {
        var sn = req.body['sn'];
        sql = "UPDATE `binjiun_project`.`l7b_gp_action_table` SET `taskflag` = 'N' WHERE (`sn` = ?);"
        insert_43811(sql, [sn])
        res.json({ 'msg': 'OK' });;
    });
    router.post('/portal/l7B_GP_KPI/getitemyId_action',urlencodedParser, function (req, res) {
        var sn = req.body.sn;
        var sql = "SELECT * FROM binjiun_project.l7b_gp_action_table where sn = ? ;"
        get_43811_data(sql,[sn])
            .then(function (results) {
                res.json(results);
        });
    });


    //api follow item
    
    router.get('/portal/l7B_GP_KPI/downloadFiles',urlencodedParser, function (req, res) {
    
        var upload_id = req.param('id');
        var file = '/' + String(upload_id).replace('dowlands ','').replace(':','')
        res.download(__dirname + '/assets/images/gpkpi' + file ,  file.split('_')[   file.split('_').length-1] ,'/' + file.split('_').length-1, function (error) {
            console.log("Error : ",  error)
        });
    });
    router.post('/portal/l7B_GP_KPI/deleteFiles',urlencodedParser, function (req, res) {
    
        var upload_id = req.body.id;
        insert_43811("DELETE FROM `binjiun_project`.`l7b_gp_item_report` WHERE (`id` >= '1') and report_name = ?; ",[upload_id.replace('delete ','').replace(':','')])
        res.json({ 'msg': 'OK' });;
    });

    router.post('/portal/l7B_GP_KPI/profile', upload_file.single('uploadFilesItem'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var upload_id = req.body.upload_id;
        var filename =  req.file.filename;
        var sql = "INSERT INTO `binjiun_project`.`l7b_gp_item_report` (`id`, `report_name`, `updatetime`) VALUES (?, ?, ?);"
        get_date().then(function (now_date) {
            insert_43811(sql,[upload_id.split('_')[1],filename,now_date])
        })
        res.json({ 'msg': 'OK' });;
     });


    router.post('/portal/l7B_GP_KPI/getProjectReportById',urlencodedParser, function (req, res) {
        
        var sn = req.body.sn;
        var sql = "SELECT * FROM binjiun_project.l7b_gp_item_report where id = ? ;"
        get_43811_data(sql,[sn])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post('/portal/l7B_GP_KPI/getitemyId',urlencodedParser, function (req, res) {
        var sn = req.body.sn;
        var sql = "SELECT * FROM binjiun_project.l7b_gp_follow_item where sn = ? ;"
        get_43811_data(sql,[sn])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post('/portal/l7B_GP_KPI/delete_item', urlencodedParser, function (req, res) {
        var sn = req.body['sn'];
        sql = "UPDATE `binjiun_project`.`l7b_gp_follow_item` SET `taskflag` = 'N' WHERE (`sn` = ?);"
        insert_43811(sql, [sn])
        res.json({ 'msg': 'OK' });;
    });

    router.get('/portal/l7B_GP_KPI/get_gp_item_data', urlencodedParser, function (req, res) {
        get_gp_item_data()
            .then(function (results) {
                res.json(results);
            });
    });

    router.post('/portal/l7B_GP_KPI/post_addproject', upload.single('file_png'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var iday = req.body.iday;
        var stage =  req.body.stage;
        var gp_dept =  req.body.gp_dept;
        var type =  req.body.type;
        var descripe =  req.body.descripe;
        var creator =  req.body.creator;
        if(req.file && req.file.originalname){
            var filename =  req.file.filename;
        }else{
            var filename = ''
        }
        var sql = "INSERT INTO `binjiun_project`.`l7b_gp_follow_item` (`iday`, `status`, `stage`, `dept`, `type`, `descripe`, `file_png`, `creator`, `createtime`, `taskflag`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?);"
        get_date().then(function (now_date) {
            insert_43811_req(sql,[iday,'未回覆',stage,gp_dept,type,descripe,filename,creator,now_date,'Y']).then(function (return_data) {
                get_insert_gp_item_data()
                .then(function (results) {
                    res.json(results);
                });
            });
        })
    }); 

    router.post('/portal/l7B_GP_KPI/post_editproject', upload.single('applypng'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var sn = req.body.edit_id;
        var applycomment =  req.body.applycomment;
        var applyowner =  req.body.applyowner;
        if(req.file && req.file.originalname){
            var filename =  req.file.filename;
        }else{
            var filename = ''
        }
        var sql = "UPDATE `binjiun_project`.`l7b_gp_follow_item` SET `status` = '待審核', `applycomment` = ?, `applypng` = ?, `applyowner` = ?, `applytime` = ? WHERE (`sn` = ?);"
        get_date().then(function (now_date) {
            insert_43811(sql, [applycomment,filename,applyowner,now_date,sn])
        })
        res.json([{ 'msg': 'OK' }]);;
    });

    router.post('/portal/l7B_GP_KPI/post_editproject_apply', upload.single('applypng'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var sn = req.body.edit_id;
        var applycomment =  req.body.applycomment;
        var applyowner =  req.body.applyowner;
        if(req.file && req.file.originalname){
            var filename =  req.file.filename;
        }else{
            var filename = ''
        }
        var sql = "UPDATE `binjiun_project`.`l7b_gp_follow_item` SET `status` = '結案', `applycomment` = ?, `applypng` = ?, `applyowner` = ?, `applytime` = ? WHERE (`sn` = ?);"
        get_date().then(function (now_date) {
            insert_43811(sql, [applycomment,filename,applyowner,now_date,sn])
        })
        res.json([{ 'msg': 'OK' }]);;
    });  

    router.post("/portal/l7B_GP_KPI/update_dep_comment", urlencodedParser, function (request, res) {
        var dept = request.body.dept;
        var comment = request.body.comment;
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                update_dep_comment(dept,comment,name,now_date)
            })
        })
        res.json({ 'msg': 'OK' });;
    });


    router.get('/portal/l7B_GP_KPI/get_l7b_gpkpi_power_comment_data', urlencodedParser, function (req, res) {
        get_l7b_gpkpi_power_comment_data()
            .then(function (results) {
                res.json(results);
            });
    });
        //router

    router.get('/portal/l7B_GP_KPI', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            // response.render('./portal/ejs/error_person.ejs')
                            response.render('./portal/ejs/gpkpi', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            response.render('./portal/ejs/gpkpi', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });
    router.get('/portal/l7B_GP_KPI2', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            // response.render('./portal/ejs/error_person.ejs')
                            response.render('./portal/ejs/gpkpi2', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            response.render('./portal/ejs/gpkpi2', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });
    router.get('/portal/l7B_GP_KPI_DEMO', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            // response.render('./portal/ejs/error_person.ejs')
                            response.render('./portal/ejs/gpkpi3', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW l7B_GP_KPI', now_date])
                            })
                            response.render('./portal/ejs/gpkpi3', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });
    return router;
}