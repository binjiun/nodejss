const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"

get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------

function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}

get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}

//expense api


get_expense_data = function (dep) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM expense_management.cost_record order by sn DESC;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_expense_set = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM expense_management.dep_vendor;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

update_expense_cell_data = function (field, value, SN) {


    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "UPDATE `expense_management`.`cost_record` SET `" + field + "` = '" + value + "' WHERE (`sn` = '" + SN + "');"

    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });

}


update_expense_data_batch = function (sn, PR_NO, Flower_NO,REMARK,name) {
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = ("0" + date_ob.getHours()).slice(-2);
    let minutes = ("0" + date_ob.getMinutes()).slice(-2);
    let seconds = ("0" + date_ob.getSeconds()).slice(-2);
    let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;


    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    var sql = "UPDATE `expense_management`.`cost_record` SET `PR_No` = '" + PR_NO + "' , `APPLY_No` = '" + Flower_NO + "'  , `REMARK` = '" + REMARK + "'   , `Updator` = '" + name + "'  , `Updatetime` = '" + now_date + "'  WHERE (`sn` in( "+ sn + "));"
    connection.query(sql, function (err, result) {
        if (err) {
            console.log('[UPDATE ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------UPDATE----------------------------');
        console.log('UPDATE ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });

}


//------------------------------------------------------------------------------
module.exports = function () {

    //router

    router.post("/portal/expense/update_set", urlencodedParser, function (request, res) {

        var sn = request.body.sn;
        var check = request.body.check;
        var sql = "UPDATE `expense_management`.`dep_vendor` SET `check` = ?, `updator` = ?, `updatetime` = ? WHERE (`sn` = ?);"
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                insert_43811(sql, [check,name,now_date,sn])
            })
        })
        res.json({ 'msg': 'OK' });
    });

    router.post('/portal/update_expense_data_batch', urlencodedParser, function (req, res) {
        var sn = req.body.sn;
        var PR_NO = req.body.PR_NO;
        var Flower_NO = req.body.Flower_NO;
        var REMARK = req.body.REMARK;
        get_ip_hostname(req.headers['x-forwarded-for']).then(function (name) {
            get_person_data(name)
                .then(function (results) {
                    if (results.length != 0) { 
                        update_expense_data_batch(sn, PR_NO, Flower_NO,REMARK,results[0].USER_NAME) 
                        res.json({ 'msg': 'OK' });
                    }
                })
                .catch(function (err) {
                    console.log("Promise rejection error: " + err);
                })

        })

    });

    router.post('/portal/update_expense_cell_data', urlencodedParser, function (req, res) {
        var field = req.body.field;
        var value = req.body.value;
        var SN = req.body.SN;
        update_expense_cell_data(field, value, SN)
        res.json({ 'msg': 'OK' });
    });

    router.get('/portal/data/get_expense_data', urlencodedParser, function (req, res) {
        get_expense_data()
            .then(function (results) {
                res.json(results);
            });
    });
    router.get('/portal/data/get_expense_set', urlencodedParser, function (req, res) {
        get_expense_set()
            .then(function (results) {
                res.json(results);
            });
    });


    router.get('/portal/fee', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW fee', now_date])
                            })
                            // response.render('./portal/ejs/error_person.ejs')
                            response.render('./portal/ejs/fee', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW fee', now_date])
                            })
                            response.render('./portal/ejs/fee', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });






    return router;
}