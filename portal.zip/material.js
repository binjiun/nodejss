const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"

get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------

function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}

get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}

//smart_ary api


update_price_data = function (data,name) {
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = ("0" + date_ob.getHours()).slice(-2);
    let minutes = ("0" + date_ob.getMinutes()).slice(-2);
    let seconds = ("0" + date_ob.getSeconds()).slice(-2);
    let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
    var result_data = JSON.parse(data);
    var sql =  "INSERT INTO `binjiun_project`.`material_price` (`stage`, `name`, `item_name`, `UOM`, `value`, `txn_date`, `descript`, `updator`, `updatetime`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);"
    for(var i = 0 ; i < result_data.length;i++){
        const item = result_data[i];
        insert_43811(sql, [item['stage'], item['name'], item['ITEM NAME'], item['UOM'],item['UNIT_PRICE_UPDATE'],item['TXN DATE'],item['ITEM DESCRIPTION'],name,now_date])

    }
}

get_price_data = function (dep) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "select stage,name, item_name,value,UOM, max(txn_date) as date,updator,updatetime from binjiun_project.material_price group by item_name order by stage"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

//------------------------------------------------------------------------------
module.exports = function () {

    //router

    router.get('/portal/material/get_price_data', urlencodedParser, function (req, res) {
        get_price_data()
            .then(function (results) {
                res.json(results);
            });
    });


    router.post('/portal/material/update_price_data', urlencodedParser, function (request, res) {
        var data = request.body.data;
        update_price_data(data);
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

            get_person_data(name)
                .then(function (results) {
                    if (results.length == 0) {
                        update_price_data(data,'訪客')
                    } else {
                        update_price_data(data,results[0].USER_NAME)
                       
                    }

                })
                .catch(function (err) {
                    console.log("Promise rejection error: " + err);
                })

        })
        res.json({ 'msg': 'OK' });
    });



    router.get('/portal/material', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW material', now_date])
                            })
                            response.render('./portal/ejs/error_person.ejs')
                            // response.render('./portal/ejs/material', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW material', now_date])
                            })
                            response.render('./portal/ejs/material', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });

    return router;
}