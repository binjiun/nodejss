const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"


get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------

function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}

get_43811_data = function (sql,data) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        connection.query(
            sql, data,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_39863_data = function (sql,data) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100039863',
            user: 'l7bmfg_ap',
            password: 'l7bmfg$ap',
            port: '3306',
            database: 'ai'
        });
        connection.connect();
        connection.query(
            sql, data,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_person_data_auo = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.auo_c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}

//api
get_EPMS_list_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l8a_auto_check_spec where DEPT LIKE 'ML7B%' ;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_check_list_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT `DEPT`,`EPMS`,sum(`Check`),count(`DEPT`) as number,`mfg_day`,`dcc_no`,`dcc_version`,check_time ,CASE WHEN TIME(check_time) BETWEEN '07:30:00' AND '19:30:00' THEN '上午' ELSE '下午'"
        sql += " END as time_label FROM binjiun_project.l7b_auto_check_history WHERE mfg_day >= CURDATE() - INTERVAL 7 DAY group by EPMS,dcc_no,check_time order by EPMS,mfg_day"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_check_detail_data = function () {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.l7b_auto_check_history WHERE mfg_day >= CURDATE() - INTERVAL 7 DAY ; ;"
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}


module.exports = function () {
    //api
    router.get('/portal/autocheck/get_estone_data',urlencodedParser, function (req, res) {
        
        let date = new Date(); // 获取当前日期
        date.setDate(date.getDate() - 7); // 设定日期为七天之前
        
        let day = ("0" + date.getDate()).slice(-2);
        let month = ("0" + (date.getMonth() + 1)).slice(-2);
        let year = date.getFullYear();
        
        // 输出形式为 'YYYY-MM-DD'
        let sevenDaysAgo = year + "-" + month + "-" + day;
        let sql = "select * from ai. l7b_ds_estone_center where source_name = 'L7B_autocheck' and shift_date >= ?"
        get_39863_data(sql,[sevenDaysAgo])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post("/portal/autocheck/export_error", urlencodedParser, function (request, res) {

        var sopno = request.body.sopno;
        var sql = "INSERT INTO `binjiun_project`.`l7b_autocheck_error` (`sopno`, `check`, `check_time`, `updatetime`, `updator`) VALUES (?, 'N', '', ?, ?);"
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                insert_43811(sql, [sopno,now_date,name])
            })
        })
        res.json({ 'msg': 'OK' });
    });

    router.post("/portal/autocheck/update_check_history_comment", urlencodedParser, function (request, res) {
        var comment = request.body.comment;
        var spec_id = request.body.spec_id;
        var DEPT = request.body.DEPT;
        var check_time = request.body.check_time;
        var EPMS = request.body.EPMS;
        var TOOL_ID = request.body.TOOL_ID;
        var CHAMBER = request.body.CHAMBER;
        var PARAMETER = request.body.PARAMETER;
        var mfg_day = request.body.mfg_day;
        var sql = "UPDATE `binjiun_project`.`l7b_auto_check_history` SET `Comment` = ? WHERE (`spec_id` = ?) and (`DEPT` = ?) and (`check_time` = ?) and (`EPMS` = ?) and (`TOOL_ID` = ?) and (`CHAMBER` = ?) and (`PARAMETER` = ?) and (`mfg_day` = ?);"
        console.log(comment)
        insert_43811(sql, [comment,spec_id,DEPT,check_time,EPMS,TOOL_ID,CHAMBER,PARAMETER,mfg_day])
        res.json({ 'msg': 'OK' });
    });

    
    router.get('/portal/autocheck/get_person_data', urlencodedParser, function (request, response) {
        get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

            get_person_data_auo(name)
                .then(function (results) {
                    if (results.length == 0) {
                        response.json({ 'name': '訪客', 'id': '' })
                    } else {
                        response.json({ 'data': results[0]})
                    }
                })
                .catch(function (err) {
                    response.json("Promise rejection error: " + err);
                })

        })

    });

    //router
    router.get('/portal/autocheck/get_EPMS_list_data', urlencodedParser, function (req, res) {
        get_EPMS_list_data()
            .then(function (results) {
                res.json(results);
            });
    });
    router.get('/portal/autocheck/get_check_list_data', urlencodedParser, function (req, res) {
        get_check_list_data()
            .then(function (results) {
                res.json(results);
            });
    });
    router.get('/portal/autocheck/get_check_detail_data', urlencodedParser, function (req, res) {
        get_check_detail_data()
            .then(function (results) {
                res.json(results);
            });
    });

    router.get('/portal/autocheck', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW expense', now_date])
                            })
                            // response.render('./portal/ejs/error_person.ejs')
                            response.render('./portal/ejs/autocheck', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW expense', now_date])
                            })
                            response.render('./portal/ejs/autocheck', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })

            })
        }
    });






    return router;
}