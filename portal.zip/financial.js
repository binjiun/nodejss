const router = require('express').Router();
const os = require('os')
var querystring = require('querystring');
var http = require('http');
const mysql = require('mysql');
const bodyParser = require('body-parser')
const jsonParser = bodyParser.json()
const urlencodedParser = bodyParser.urlencoded({ extended: false })
const ip_sql = "INSERT INTO `binjiun_project`.`node_portal_ip` (`ip`, `hostname`, `action`, `updatetime`) VALUES (?, ?, ?, ?);"

const multer  = require('multer')

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'router/portal/financial_uploads/')
    },
    filename: function (req, file, cb) {
        file.originalname = Buffer.from(file.originalname, "latin1").toString(
            "utf8"
        );

      cb(null, req.body.upload_id + '_' + file.originalname)
    },
    limit: {
        // 限制上傳檔案的大小為 10MB
        fileSize: 10000000
    },
})
const upload = multer({storage: storage})



get_date = function () {
    return new Promise(function (resolve, reject) {
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let year = date_ob.getFullYear();
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let seconds = date_ob.getSeconds();
        let now_date = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
        resolve(now_date)
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// host sql api--------------------------------------------------------------------------

function insert_43811(sql, data) {
    const connection = mysql.createConnection({
        host: 'tw100043811',
        user: 'l7b01_ap',
        password: 'l7b01$ap',
        port: '3306',
        database: 'binjiun_project'
    });
    connection.connect();
    connection.query(sql, data, function (err, result) {
        if (err) {
            console.log('[INSERT ERROR] - ', err.message);
            return;
        }

        console.log('--------------------------INSERT----------------------------');
        console.log('INSERT ID:', result);
        console.log('-----------------------------------------------------------------\n\n');
    });
    connection.end();



}

get_43811_data = function (sql,data) {
    return new Promise(function (resolve, reject) {
        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        connection.query(
            sql, data,
            function (err, rows) {
                if (rows === undefined) {
                    reject(new Error("Error rows is undefined"));
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}

get_person_data = function (data) {
    return new Promise(function (resolve, reject) {

        const connection = mysql.createConnection({
            host: 'tw100043811',
            user: 'l7b01_ap',
            password: 'l7b01$ap',
            port: '3306',
            database: 'binjiun_project'
        });
        connection.connect();
        var sql = "SELECT * FROM binjiun_project.c_fac_user_mst where hostname = '" + data + "' ;";
        connection.query(
            sql,
            function (err, rows) {
                if (rows === undefined) {
                    // reject(new Error("Error rows is undefined"));
                    resolve([{ 'USER_NAME': '訪客', 'USER_ID': '' }]);
                } else {
                    var normalResults = rows.map((mysqlObj, index) => {
                        return Object.assign({}, mysqlObj);
                    });
                    connection.end();
                    resolve(normalResults);
                }
            }
        )
    }
    )
}




get_ip_hostname = function (ip) {
    if (ip === undefined) {
        return new Promise(function (resolve, reject) {
            resolve('訪客');
        })
    }
    return new Promise(function (resolve, reject) {
        require('dns').reverse(ip, function (err, domains) {
            if (domains === undefined) {
                // reject(new Error("Error rows is undefined"));
                resolve('訪客');
            } else {
                resolve(String(domains).split('.')[0])
            }
        })
    }
    )
}


//api
module.exports = function () {

    //api

    router.get('/portal/financial/downloadFiles',urlencodedParser, function (req, res) {
    
        var upload_id = req.param('id');
        var file = '/' + String(upload_id).replace('dowlands ','')
        res.download(__dirname + '/financial_uploads' + file ,  file.split('_')[   file.split('_').length-1] , function (error) {
            console.log("Error : ",  error)
        });
    });

    router.post('/portal/financial/deleteFiles',urlencodedParser, function (req, res) {
    
        var upload_id = req.body.id;
        var month = upload_id.split('_')[1];
        var type = upload_id.split('_')[2];

        insert_43811("DELETE FROM `binjiun_project`.`l7b_financial_target` WHERE (`month` = ?) and (`ITEM` = ?) and (`DEPT` = 'PASS') and (`type` != ''); ",[month,type])
        res.json({ 'msg': 'OK' });;
    });

    router.post('/portal/financial/getProjectReportById',urlencodedParser, function (req, res) {
    
        var upload_id = req.body.id;
        var month = upload_id.split('_')[1];
        var type = upload_id.split('_')[2];
        var sql = "SELECT * FROM `binjiun_project`.`l7b_financial_target`  where type like '%file%' and `month` = ? and `ITEM` = ? ;"
        get_43811_data(sql,[month,type])
            .then(function (results) {
                res.json(results);
        });
    });

    router.post('/portal/financial/profile', upload.single('uploadFilesItem'), function (req, res) {
        // req.file is the name of your file in the form above, here 'uploaded_file'
        // req.body will hold the text fields, if there were any 
        var upload_id = req.body.upload_id;
        var month = upload_id.split('_')[1];
        var type = upload_id.split('_')[2];
        var value =  req.file.filename;
        console.log(upload_id);
        var sql2 = "REPLACE INTO `binjiun_project`.`l7b_financial_target` (`month`, `ITEM`, `DEPT`, `action`, `updator`, `updatetime`, `type`) VALUES (?, ?, ?, ?, ?, ?,?);"; 
        var sql = "SELECT * FROM `binjiun_project`.`l7b_financial_target`  where type Like '%file%' and `month` = ? and `ITEM` = ? ;"
        get_43811_data(sql,[month,type])
            .then(function (results) {
                get_date().then(function (now_date) {
                    get_ip_hostname(req.headers['x-forwarded-for']).then(function (name) {
                        insert_43811(sql2,[month,type,'PASS',value,name,now_date,'file' + String(results.length)])
                        res.json({ 'msg': 'OK' });;
                    })
                })
        });
        
     });

    router.post("/portal/financial/update_action", urlencodedParser, function (req, res) {

        var month = req.body.month;
        var type = req.body.type;
        var dept = 'PASS';
        var value = req.body.value;
        var sql = "REPLACE INTO `binjiun_project`.`l7b_financial_target` (`month`, `ITEM`, `DEPT`, `action`, `updator`, `updatetime`, `type`) VALUES (?, ?, ?, ?, ?, ?,'action');"; 
        get_ip_hostname(req.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                insert_43811(sql,[month,type,dept,value,name,now_date])
                res.json({ 'msg': 'OK' });;
            })
        })
    });


    router.post("/portal/financial/update_target", urlencodedParser, function (req, res) {

        var day = req.body.day;
        var dep = req.body.dep;
        var type = req.body.type;
        var value = req.body.value;
        var sql = "REPLACE INTO `binjiun_project`.`l7b_financial_target` (`month`, `ITEM`, `DEPT`, `target`, `updator`, `updatetime`, `type`) VALUES (?, ?, ?, ?, ?, ?,'target');"; 
        get_ip_hostname(req.headers['x-forwarded-for']).then(function (name) {
            get_date().then(function (now_date) {
                insert_43811(sql,[day,type,dep,value,name,now_date])
                res.json({ 'msg': 'OK' });;
            })
        })
    });

    router.post("/portal/financial/get_target", urlencodedParser, function (req, res) {
        var month = req.body.month;
        var sql = "SELECT * FROM binjiun_project.l7b_financial_target where month = ?;"; 
        get_43811_data(sql,[month])
            .then(function (results) {
                res.json(results);
        });
    });

    

        //router

    router.get('/portal/financial', (request, response) => {

        if ((request.headers['user-agent']).includes('Trident')) {
            response.sendFile('swal.html', { root: __dirname })
        } else {
            const val = getRandomInt(1000);
            get_ip_hostname(request.headers['x-forwarded-for']).then(function (name) {

                get_person_data(name)
                    .then(function (results) {
                        if (results.length == 0) {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW Financial', now_date])
                            })
                            response.render('./portal/ejs/error_person.ejs')
                            // response.render('./portal/ejs/financial', { 'name': '訪客', 'id': '' })
                        } else {
                            get_date().then(function (now_date) {
                                insert_43811(ip_sql, [request.headers['x-forwarded-for'], name, 'VIEW Financial', now_date])
                            })
                            response.render('./portal/ejs/financial', { 'name': results[0].USER_NAME, 'id': results[0].USER_ID })
                        }

                    })
                    .catch(function (err) {
                        console.log("Promise rejection error: " + err);
                    })
            })
        }
    });






    return router;
}